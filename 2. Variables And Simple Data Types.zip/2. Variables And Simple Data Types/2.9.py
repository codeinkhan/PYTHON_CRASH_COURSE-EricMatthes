#2-9. Number Eight: Write addition, subtraction, multiplication, and division operations that each result in the number 8.
#     Be sure to enclose your operations in print() calls to see the results. You should create four lines that look like this:
#     print(5+3) Your output should be four lines, with the number 8 appearing once on each line.

print(5+3)
print(10-2)
print(2*4)
print(16/2)
