#2-4. Name Cases: Use a variable to represent a person's name, and then print
#     that person's name in lowercase, uppercase, and title case.

name='codein khan';
print (name.title())
print (name.lower())
print (name.upper())


