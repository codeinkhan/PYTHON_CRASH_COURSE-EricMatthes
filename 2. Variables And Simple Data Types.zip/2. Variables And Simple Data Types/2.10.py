#2-10. Favorite Number: Use a variable to represent your favorite number. Then, using that variable, create a message that reveals your favorite number. Print that message.

FavNumber=7;
print("My Favorite Number is "+ str(FavNumber))
