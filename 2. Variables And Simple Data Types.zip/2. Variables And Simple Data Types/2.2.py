#2-2. Simple Messages: Assign a message to a variable, and print that message. Then
#     change the value of the variable to a new message, and print the new message.

message="You Can Do It, Just Stay Committed";
print (message)

message="Its a Long Way But Its Beautiful";
print(message)
