#2-1. Simple Message: Assign a message to a variable, and then print that message.
message="You Can Do It, Just Stay Committed";
print (message)

