#2-6. Famous Quote 2: Repeat Exercise 2-5, but this time, represent the famous person's name using a variable called famous person.
#     Then compose your mes sage and represent it with a new variable called message. Print your message.

name="Prophet Muhammad";
print(name+' once said, "A good man treats women with honour."')
